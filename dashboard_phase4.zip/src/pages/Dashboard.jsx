import { useCallback, useEffect, useState } from "react";
import { useAuth } from "../AuthContext";
import { api } from "../api/client";
import DoorCard from "../components/DoorCard";
import AlertBanner from "../components/AlertBanner";
import LogsTable from "../components/LogsTable";

const POLL_MS = 5000;

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [doors, setDoors] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [logs, setLogs] = useState([]);
  const [selectedDoorId, setSelectedDoorId] = useState(null);
  const [err, setErr] = useState(null);

  const canOverride = user?.role === "admin";

  const refresh = useCallback(async () => {
    try {
      const [doorList, alertList] = await Promise.all([
        api.listDoors(),
        api.listAlerts(false),
      ]);
      setDoors(doorList);
      setAlerts(alertList);
      setErr(null);
    } catch (e) {
      setErr(e.message);
    }
  }, []);

  const refreshLogs = useCallback(async (doorId) => {
    if (doorId == null) {
      setLogs([]);
      return;
    }
    try {
      const doorLogs = await api.doorLogs(doorId);
      setLogs(doorLogs);
    } catch (e) {
      setErr(e.message);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, POLL_MS);
    return () => clearInterval(id);
  }, [refresh]);

  useEffect(() => {
    refreshLogs(selectedDoorId);
  }, [selectedDoorId, refreshLogs]);

  async function handleOverride(doorId, action) {
    try {
      await api.overrideDoor(doorId, action);
      await refresh();
      if (selectedDoorId === doorId) await refreshLogs(doorId);
    } catch (e) {
      setErr(e.message);
    }
  }

  async function handleResolve(alertId) {
    try {
      await api.resolveAlert(alertId);
      await refresh();
    } catch (e) {
      setErr(e.message);
    }
  }

  return (
    <div className="dashboard">
      <header className="topbar">
        <h1>Smart Access Control &mdash; Admin Dashboard</h1>
        <div className="topbar-user">
          <span>{user?.email} ({user?.role})</span>
          <button className="secondary" onClick={logout}>Sign out</button>
        </div>
      </header>

      <main>
        {err && <div className="form-error">{err}</div>}

        <AlertBanner alerts={alerts} onResolve={handleResolve} canResolve={canOverride} />

        <section className="door-grid">
          {doors.map((door) => (
            <DoorCard
              key={door.door_id}
              door={door}
              canOverride={canOverride}
              onOverride={handleOverride}
              onViewLogs={setSelectedDoorId}
            />
          ))}
        </section>

        <LogsTable
          logs={logs}
          title={selectedDoorId ? `Access Events — Door #${selectedDoorId}` : "Select a door to view history"}
        />
      </main>
    </div>
  );
}
